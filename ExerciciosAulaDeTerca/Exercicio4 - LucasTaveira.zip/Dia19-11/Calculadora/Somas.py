def mais(a, b):
    return a + b

def subtracao(a, b):
    return a - b

def multiplica(a, b):
    return a * b

def divisao(a, b):
    if b == 0:
        return "Erro, impossivel fazer divisao por 0!"
    return a / b

def potencia(a, b):
    return a ** b

def raiz(a):
    return a ** 0.5
